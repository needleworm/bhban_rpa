# pixabay_crawling
Pixabay 저작권 없는 이미지 크롤링

# Dependenceis
크롬이 설치되어 있어야 합니다.
폴더 내에 버전이 맞는 크롬 드라이버를 위치시켜야 합니다.

> pip install selenium

# 사용방법
> python main.py \<keyword> \<number> <result_dir> <high_resolution>


keyword : 검색 하려는 키워드

number : 이미지 장 수

result_dir : 결과 파일 저장할 폴더 이름

high_resolution (t / f / T / F / True / False / true / false)

True면 고화질 이미지 다운로드, False면 썸네일 다운로드.
