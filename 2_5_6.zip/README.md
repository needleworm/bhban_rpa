# 예제를 위해 사진 한 장을 1440장으로 부풀리기
### 아래 명령어를 입력하면 코드가 실행됩니다.

> python augmentation.py <SAMPLE_FILE\>
