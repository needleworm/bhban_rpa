# 서식이 올바른 엑셀파일, 순식간에 합치기

### 아래 명령어를 입력하시면 코드가 실행됩니다.

>python merge_correct_xlsx.py <TEMPLATE\> <DIRECTORY\>

<TEMPLATE\> 에는 양식 견본이 될 엑셀파일 이름을 적어줍니다.

<DIRECTORY\> 에는 분석 대상 폴더를 입력합니다.
