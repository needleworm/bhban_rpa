# 엑셀 파일의 내용물을 엉망으로 만들어버리는 자동화

### 아래 명령어를 입력하시면 코드가 실행됩니다.

>python terrorist.py <DIRECTORY\> <PERCENT\>

<DIRECTORY\> 에는 대상 폴더를 입력합니다.

<PERCENT\>에는 몇 퍼센트의 데이터를 파괴할 것인지 기재합니다.

책의 예제는 아래와 같습니다.

python terrorist.py merged_personal_info 30
