# 섞여 있는 엑셀 파일 1천 개, 서식이 몇 종류인지 분석하기

###아래 명령어를 입력하시면 코드를 실행할 수 있습니다.
>python analyst.py <DIRECTORY\> <REPORT\>

<DIRECTORY\>에는 분석하고자 하는 파일들이 저장된 폴더를 입력해 주세요.


<REPORT\>에는 분석 결과 보고서 파일 이름을 적어 주세요.


이 책의 예제는 아래와 같습니다.

>python analyst.py personal_info report.txt
