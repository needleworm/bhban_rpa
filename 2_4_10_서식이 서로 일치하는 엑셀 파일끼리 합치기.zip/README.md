# 서식이 서로 일치하는 엑셀 파일끼리 합치기

### 아래 명령어를 입력하시면 코드가 실행됩니다.

>python merge_same_xlsx_files.py <DIRECTORY\>

<DIRECTORY\> 에는 엑셀 파일들이 저장된 폴더를 입력합니다.
