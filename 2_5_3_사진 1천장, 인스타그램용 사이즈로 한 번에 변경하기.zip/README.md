# 사진 1천장, 인스타그램용 사이즈로 한 번에 변경하기

### 아래 명령어를 입력하면 코드가 실행됩니다.

>python insta_jungdok.py <DIRECTORY\> <COLOR\>

<DIRECTORY\>에는 크기를 변환할 사진들이 저장된 폴더 이름을 기재합니다.

<COLOR\>에는 배경으로 지정할 색깔을 입력합니다.

white, black, blue, red, ... 등 왠만한 색상은 입력 가능합니다.
상세한 목록은 Python Image Library 설명서를 검색해 보세요.
