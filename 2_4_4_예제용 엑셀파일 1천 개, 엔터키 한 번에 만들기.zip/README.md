# 예제용 엑셀파일 1천 개, 엔터키 한 번에 만들기


###아래 명령어를 실행하여 라이브러리를 설치해 주세요

> pip install pyexcel pyexcel-xlsx 


###아래 명령어를 실행하시면 예제용 엑셀파일 1000개가 생깁니다.

> python sample_xlsx_generator.py 
