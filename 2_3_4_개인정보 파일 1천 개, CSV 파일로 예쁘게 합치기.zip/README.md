# 개인정보 파일 1천 개, CSV 파일로 예쁘게 합치기


아래 명령어를 실행하시면 예제가 실행됩니다.

> python merge_into_csv.py
