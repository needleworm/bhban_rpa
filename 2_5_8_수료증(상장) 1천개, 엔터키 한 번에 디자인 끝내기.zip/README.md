# 수료증(상장) 1천개, 엔터키 한 번에 디자인 끝내기
### 아래 명령어를 입력하면 코드가 실행됩니다.

> python congratulation.py <PERSONAL_ID\> <TEMPLATE\>

<PERSONAL_ID\>에는 개인정보가 기재된 CSV파일을 입력합니다. 이 책의 3장의 4장 예제코드 결과물을 활용하세요.

<TEMPLATE\> 에는 템플릿 파일을 입력합니다.