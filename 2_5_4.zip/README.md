# 사진 1천장, 한 번에 로고 삽입하기
### 아래 명령어를 실행하면 코드가 실행됩니다.

>python insert_logo.py <DIRECTORY\> <LOGOFILE\>

<DIRECROTY\>에는 명령을 수행할 사진 파일들이 들어있는 폴더 이름을 적어줍니다.

<LOGOFILE\>에는 삽입할 로고파일 이름을 적어줍니다. 
