# 회원 개인정보 파일 1천 개, 한 번에 엑셀로 합치기

###아래 코드를 입력하시면 예제를 실행할 수 있습니다.
> python merge.py <DIRECTORY\>

###<DIRECTORY\>에는 하나로 합치려는 파일이 저장된 폴더 이름을 적어줍니다.

책의 예제는 아래와 같습니다.

>python merge.py personal_info
