# 무작위 엑셀 파일의 서식을 망가뜨리자

### 아래 명령어를 입력하면 코드가 실행됩니다.

>python anarchist.py <DIRECTORY\> <PERCENT\>

<DIRECTORY\> 에는 공격 대상이 되는 파일들이 저장된 폴더 이름을 입력합니다.

<PERCENT\> 에는 서식을 망가뜨릴 파일의 비율을 입력합니다. 
1부터 100까지의 숫자를 입력하시면 됩니다. 
예를 들어, 24를 입력하시면 전체 파일 중 24% 파일의 서식을 망가뜨립니다.

이 책의 예제는 아래와 같습니다.

>python anarchist.py personal_info 30