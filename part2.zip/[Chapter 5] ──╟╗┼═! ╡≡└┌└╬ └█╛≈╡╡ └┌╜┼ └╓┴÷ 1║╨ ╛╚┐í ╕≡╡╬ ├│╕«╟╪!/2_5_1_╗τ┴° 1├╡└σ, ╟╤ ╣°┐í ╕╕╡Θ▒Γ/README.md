# 사진 1천장, 한 번에 만들기

### 아래 명령어를 입력하면 코드가 실행됩니다.

>python noise.py

### numpy 모듈과 PIL 모듈이 필요합니다.

> pip install numpy

> pip install pillow