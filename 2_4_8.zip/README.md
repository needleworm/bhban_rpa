# 서식이 잘못된 엑셀파일을 찾아내고, 처리해라!

### 아래 명령어를 입력하시면 코드가 실행됩니다.

>python sorter.py <TEMPLATE\> <DIRECTORY\> <MODE\>

<TEMPLATE\> 에는 양식 견본이 될 엑셀파일 이름을 적어줍니다.

<DIRECTORY\> 에는 분석 대상 폴더를 입력합니다.

<MODE\> 에는 어떤 모드로 작동시킬 것인지 적어줍니다.

delete : 서식이 잘못된 파일 삭제

report : 서식이 잘못된 파일 파일명 보고

separate : 서식이 잘못된 파일을 다른 폴더로 이동
