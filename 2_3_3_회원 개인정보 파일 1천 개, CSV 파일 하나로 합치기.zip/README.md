# 회원 개인정보 파일 1천 개, 1초만에 CSV 파일 하나로 합치기

아래 명령어를 실행하시면 예제가 실행됩니다.

> python simple_merge_into_csv.py
