# 회원 개인정보 파일 1천 개, 1초만에 텍스트 파일 하나로 합치기

아래 명령어를 실행하시면 됩니다.

> python merge_txt_files.py