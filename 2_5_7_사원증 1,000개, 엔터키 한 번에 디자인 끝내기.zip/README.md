# 사원증 1,000개, 엔터키 한 번에 디자인 끝내기
### 아래 명령어를 입력하면 코드가 실행됩니다.

> python idcard.py <DIRECTORY\> <PEOPLE\> <SAMPLE_LOGO\> <TEMPLATE\>

<DIRECTORY\> 에는 사원들의 증명사진이 들어있는 폴더명을 적어줍니다. 6절의 예제 결과 폴더를 활용합시다.

<PEOPLE\>에는 개인정보가 기재된 CSV파일을 입력합니다. 
이 책의 3장의 4절 예제 결과물을 이용하세요.

<SAMPLE_LOGO\>에는 명함에 삽입할 로고를 입력합니다. 

<TEMPLATE\> 에는 템플릿 파일을 입력합니다. 흰 배경으로 불러오려면 false 를 입력합니다.