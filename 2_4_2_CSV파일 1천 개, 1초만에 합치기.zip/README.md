# CSV 파일 1천 개, 1초만에 합치기

###아래 코드를 입력하시면 잘못된 예제를 실행할 수 있습니다.
> python simple_merge.py <DIRECTORY\>

###<DIRECTORY\>에는 하나로 합치려는 파일이 저장된 폴더 이름을 적어줍니다.